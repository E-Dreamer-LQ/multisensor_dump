import cv2, mmcv, glob, os
import numpy as np
import os.path as osp
from tqdm import tqdm
from datetime import datetime



if __name__ == '__main__':
    DIM= (640, 480)
    K=np.array([[480,0,320],[0,480,240],[0,0,1]],dtype=np.float32)
    D=np.array([[0],[0],[0],[0]],dtype=np.float32)

    print(DIM)
    print(K)
    print(D)

    objPoints=np.array([[0.7,0,0],[0.7,0.3,0],[1,0,0],[1,0.3,0],[1,-0.3,0],[1.3,-0.3,0],[1.3,0,0]],dtype=np.float32)
    picPoints=np.array([[317,424],[74,423],[314,384],[154,381],[473,384],[431,363],[313,361]],dtype=np.float32)

    retval, rvec, tvec = cv2.solvePnP(objPoints, picPoints, K, D)
    print(retval)
    # objPoints_test = np.array([[0.67, -0.11, 0]],dtype=np.float32)
    # proj_pic_pts, jac = cv2.projectPoints(objPoints, rvec, tvec, K, D)

    rows = 200
    columns = 50
    square_size = 0.02 # 1cm

    objp = np.zeros((rows*columns, 3), np.float32)
    idx = 0
    for r in range(0, rows, 1):
        # for c in range(int(columns*0.25), columns, 1):
        for c in range(0, columns, 1):
            objp[idx, :] = [r, c-columns/2, 0] # x, y, z
            idx += 1
    objp *= square_size
    print('xx')
    all_pic_pts, jac = cv2.projectPoints(objp, rvec, tvec, K, D)
    img = cv2.imread('test_points.jpg')
    color = (255, 0, 0)
    print()
    # for pic_pts in all_pic_pts.squeeze():
    #     # print(pic_pts)
    #     cv2.circle(img, tuple(pic_pts), 2, color)

    pic_pts_arr=np.array(all_pic_pts.squeeze(), dtype=np.int32)
    #print(pic_pts_arr)
    test_pic_pts=[480,400]
    darry_sum = np.sum(abs(pic_pts_arr-test_pic_pts), axis=1)
    point_index=np.argmin(darry_sum)
    point_ground=objp[point_index]
    print(point_ground)

    # color_x = (0, 0, 255)
    # cv2.circle(img, test_pic_pts, 2, color_x,2)
    # #mmcv.imshow(img)
    # darry=
    #
    # print(darry_sum)

    # if left_right == 'right':
    #     objp[:, 1] *= -1
    #
    #
    # ### sort files by datetime & hall_counter
    # jpgs = glob.glob(fname)
    # avm_tfn_can_list = []
    # for j in jpgs:
    #     bn = osp.basename(j)
    #     bn = bn.split("_")
    #     time = datetime.strptime("_".join(bn[0:4]), '%Y_%m_%d_%H:%M:%S')
    #     hc = int( float(bn[-1].rstrip(".jpg")) / 100.0 * 1180 )
    #     avm_tfn_can_list.append((time, j, hc))
    # avm_tfn_can_list.sort(key=lambda x:(x[0], x[2]))
    #
    #
    # hcST_pose_dict = {} #  ( k: hcST, v: w2cam_pose(r,t) )
    # for (avm_t1, avm_img_fn1, hall_counter1) in avm_tfn_can_list:
    #     if not osp.exists(avm_img_fn1+"_5pts.npy"):
    #         continue
    #
    #     print(avm_t1, avm_img_fn1, hall_counter1)
    #     pts_2d = np.load(avm_img_fn1+"_5pts.npy").astype(np.float32)
    #     if len(pts_2d) != 5:
    #         continue
    #
    #
    #     ######### show hand label points
    #     idx = 1
    #     img = cv2.imread(avm_img_fn1)
    #     for point in pts_2d:
    #         cv2.circle(img,tuple(point),3,(0,0,255))
    #         cv2.putText(img, str(idx), tuple(point+10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,0))
    #         idx += 1
    #     # mmcv.imshow(img, wait_time=10)
    #
    #
    #     #### get rvec, tvec
    #     undistorted = cv2.fisheye.undistortPoints(pts_2d[np.newaxis,:,:], K, D)
    #     III=np.eye(3)
    #     IID=np.zeros((1,5))
    #     retval,rvec,tvec = cv2.solvePnP(np.ascontiguousarray(objPoints[np.newaxis,:,:]), undistorted, III, IID)
    #     # retval,rvec,tvec, inliners = cv2.solvePnPRansac(np.ascontiguousarray(objPoints[np.newaxis,:,:]), undistorted, III, IID, flags=cv2.SOLVEPNP_EPNP)
    #     assert retval, "PnP failed!"
    #
    #
    #     ##### reproject pts
    #     img = cv2.imread(avm_img_fn1)
    #     proj_pts, jac = cv2.fisheye.projectPoints(objPoints[np.newaxis,:,:], rvec, tvec, K, D)
    #     idx = 1
    #     for point in proj_pts[0,:,:]:
    #         cv2.circle(img,tuple(point),3,(0,0,255))
    #         cv2.putText(img, str(idx), tuple(point+10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255,255,0))
    #         idx += 1
    #     # mmcv.imshow(img, wait_time=10)
    #
    #
    #     ######### ground grid
    #     img = cv2.imread(avm_img_fn1)
    #     img_hight, img_width, _= img.shape
    #     proj_pts, jac = cv2.fisheye.projectPoints(objp[np.newaxis,:,:], rvec, tvec, K, D)
    #     for point in proj_pts[0,:,:]:
    #         if point[0] > img_width or point[1] > img_hight:
    #             continue
    #         cv2.circle(img,tuple(point),1,(0,0,255))
    #         # mmcv.imshow(img, wait_time=20)
    #     # mmcv.imshow(img, wait_time=0)
    #
    #
    #     # hcST_pose_dict[hall_counter1] = (rvec, tvec)
    #     hcST_pose_dict[ osp.basename(avm_img_fn1) ] = (rvec, tvec)
    #     np.save(plane_grid_3d%hall_counter1, objp)
    #     np.save(plane_grid_2d%hall_counter1, proj_pts)
    #
    #
    #     # import ipdb;ipdb.set_trace()
    #     # ground = cv2.remap(img, proj_pts,None, cv2.INTER_LINEAR)
    #     img = cv2.imread(avm_img_fn1)
    #     ground=cv2.remap(img, proj_pts[:,:,0].reshape((500,300)),proj_pts[:,:,1].reshape((500,300)), cv2.INTER_LINEAR)
    #     # mmcv.imshow(ground, win_name=osp.basename(avm_img_fn1))
    #
    #
    # #save_obj(hcST_pose_dict_path, hcST_pose_dict)
    


